package com.hsn.service;

import java.util.HashSet;

public class Bst {
	
	 public Node insert(Node root, int data)
	 {
		 if(root == null) {
			 root = new Node(data);
			 return root;
		 }
		 if (data < root.Ndata)
	            root.Nleft = insert(root.Nleft, data);
	        else if (data > root.Ndata)
	            root.Nright = insert(root.Nright, data);
	 
	        return root;
	 }
	 public boolean findPair(Node root,int sum, HashSet<Integer> hs) {
		 if (root == null)
			 return false;
		 if (findPair(root.Nleft,sum,hs))
			 return true;
		 
		 if (hs.contains(sum - root.Ndata))
		 {
			 System.out.println("The pair is found["+(sum - root.Ndata)+","+root.Ndata+"]");
			 return true;
		 }
		 else
		 hs.add(root.Ndata);
		 return findPair( root.Nright, sum,  hs);
	 }
	public void FindThePair(Node root, int sum) {
		// TODO Auto-generated method stub
		HashSet<Integer> hs = new HashSet<Integer>();
		if(!findPair(root,sum,hs))
			System.out.println("The pair is not found");
		
		
	}
	

}
