package com.hsn.service;

public class Node {
	int Ndata;
    Node Nleft, Nright;
 
    Node(int d)
    {
        Ndata = d;
        Nleft = Nright = null;
    }

}
