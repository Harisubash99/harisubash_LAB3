package com.hsn.driver;

import com.hsn.service.Bst;
import com.hsn.service.Node;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node root = null;
		Bst bs1= new Bst();
		
		root = bs1.insert(root,40);
		root = bs1.insert(root,20);
		root = bs1.insert(root,10);
		root = bs1.insert(root,50);
		root = bs1.insert(root,60);
		root = bs1.insert(root,70);
		root = bs1.insert(root,30);
		
		
		int sum = 30;
		bs1.FindThePair(root,sum);
		
	}

}
