package com.hs.main;

import com.hs.services.balancingBracket;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		balancingBracket Bbl = new balancingBracket();
		String bEx = "([[{}]])";
		Boolean result;
		
		result = Bbl.checkBalancedBracket(bEx);
		if (result)
			System.out.println("The brackets are balanced");
		else
			System.out.println("The brackets are not balanced");
		

	}

}
