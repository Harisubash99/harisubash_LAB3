package com.hs.services;

import java.util.ArrayDeque;
import java.util.Deque;

public class balancingBracket {

	public  boolean checkBalancedBracket(String bEx) {
		// TODO Auto-generated method stub
		Deque<Character> stack = new  ArrayDeque<Character>();
		for(int i=0; i<bEx.length(); i++) {
			char x= bEx.charAt(i);
			if (x== '(' || x== '[' || x=='{')
			{
				stack.push(x);
				continue;
			}
			if(stack.isEmpty())
			{
				return false;
			}
			char check;
			switch(x)
			{
			case(')'):
				check = stack.pop();
            if (check == '{' || check == '[')
                return false;
            break;
			case(']'):
			check = stack.pop();
            if (check == '(' || check == '{')
                return false;
            break;
			case('}'):
				check = stack.pop();
            if (check == '(' || check == '[')
                return false;
            break;
			}
			
		}
		return (stack.isEmpty());
	}
}
	
