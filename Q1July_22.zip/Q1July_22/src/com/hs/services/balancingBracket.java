package com.hs.services;

import java.util.Stack;

public class balancingBracket {

	public  boolean checkBalancedBracket(String bEx) {
		// TODO Auto-generated method stub
		Stack<Character> stack = new  Stack<Character>();
		for(int i=0; i<bEx.length(); i++) {
			char x= bEx.charAt(i);
			if (x== '(' || x== '[' || x=='{')
			{
				stack.push(x);
				continue;
			}
			if(stack.isEmpty())
			{
				return false;
			}
			char y;
			switch(x)
			{
			case(')'):
				y = stack.pop();
            if (y == '{' || y == '[')
                return false;
            break;
			case(']'):
			y = stack.pop();
            if (y == '(' || y == '{')
                return false;
            break;
			case('}'):
				y = stack.pop();
            if (y == '(' || y == '[')
                return false;
            break;
			}
			
		}
		return (stack.isEmpty());
	}
}
	
